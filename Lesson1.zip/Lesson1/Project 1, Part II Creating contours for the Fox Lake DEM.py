# Name: Project 1Part II.py
# Description: Creates contours or isolines from a raster surface.
# Requirements: Spatial Analyst Extension

# Import system modules
import arcpy
from arcpy import env

# Set environment settings
env.workspace = "W:/GIS projects/geog485/Lesson1/Lesson1Data"

try:
	arcpy.CheckOutExtension("Spatial")
	# Set local variables
	inRaster = "foxlake"
	contourInterval = 25
	baseContour = 0
	outContours = "foxlake_contours"

	# Execute Contour
	arcpy.Contour_3d(inRaster, outContours, contourInterval, baseContour)
	arcpy.CheckInExtension("Spatial")
	arcpy.AddMessage(outContours+" is generated")
	
except:

     # Report an error messages
     arcpy.AddError("Could not complete the analysis")
 
     # Report any error messages that the Buffer tool might have generated    
     arcpy.AddMessage(arcpy.GetMessages())

input('Press ENTER to exit')
