import arcpy
from arcpy.sa import *
inRaster = "W:\\GIS projects\\geog485\\Lesson1\\Lesson1Data\\foxlake"
cutoffElevation = 3500
arcpy.CheckOutExtension("Spatial")
outRaster = Raster(inRaster) > cutoffElevation
outRaster.save("W:\\GIS projects\\geog485\\Lesson1\\Lesson1Data\\foxlake_hi_20")
arcpy.CheckInExtension("Spatial")
input('Press ENTER to exit')
