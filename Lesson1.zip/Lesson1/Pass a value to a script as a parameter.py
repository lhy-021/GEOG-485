x = raw_input(" Hey what is your name " )       
print(" Hey, " + x)
input('Press ENTER to exit')
