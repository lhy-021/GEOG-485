import arcpy
dataset = "W:/GIS projects/geog485/Lesson1/Lesson1Data/us_boundaries.shp"
spatial_ref = arcpy.Describe(dataset).spatialReference
print spatial_ref.Name
input('Press ENTER to exit')
