def checkTeamandScore(team, score, dictionary):
	if team not in dictionary:
		dictionary[team] = score
	if team in dictionary:
		if score > dictionary[team]:
			dictionary[team] = score
		else:
			pass

import csv

score1sFile = open(r'W:\GIS projects\geog485\Lesson4\Lesson4PracticeExerciseB\Scores.txt')

csvReader = csv.reader(score1sFile, delimiter=" ")
header = csvReader.next()

soccerTeams = {}

for row in csvReader:

	team1 = row[0]
	score1 = row[1]
	team2 = row[2]
	score2 = row[3]
	
	checkTeamandScore(team1, score1, soccerTeams)
	checkTeamandScore(team2, score2, soccerTeams)

for key in soccerTeams:
    print key + ": " + soccerTeams[key]
	
lastline = raw_input(">>>")