import os
import csv
import arcpy

os.chdir(r'W:\GIS projects\geog485\Lesson4\Lesson4PracticeExerciseA')
MysteryStatePoints = open('MysteryStatePoints.txt', 'r')
MysteryState = r'W:\GIS projects\geog485\Lesson4\Lesson4PracticeExerciseA\MysteryState.shp'
spatialRef = arcpy.Describe(MysteryState).spatialReference

csvReader = csv.reader(MysteryStatePoints)

vertexArray = arcpy.Array()

for row in csvReader:
	lat = row[1]
	lon = row[0] 
	vertex = arcpy.Point(lon,lat)
	vertexArray.add(vertex)

print 'array created'

try:
	with arcpy.da.InsertCursor(MysteryState, ("SHAPE@",)) as cursor:
		Polygon = arcpy.Polygon(vertexArray, spatialRef)
		cursor.insertRow((Polygon,)) 

except:
	arcpy.AddMessage(arcpy.GetMessages())
print 'shapefile updated'
	
lastline = raw_input(">>>")