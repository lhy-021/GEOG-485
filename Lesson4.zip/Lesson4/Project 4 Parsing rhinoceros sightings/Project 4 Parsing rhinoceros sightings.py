def rhinoTracks(rhino, location, dictionary):
	if rhino not in dictionary:
		dictionary[rhino] = [location]
	else:
		dictionary[rhino].append(location)
	
def exportTracks(key, dictionary):
	features = []
	features.append(
		arcpy.Polyline(
			arcpy.Array([arcpy.Point(*coords) for coords in dictionary[key]]), sr)) 
	arcpy.CopyFeatures_management(features, exportPath + key + ".shp")
	print key + "generated"
		
import csv
import arcpy

file = open(r"W:\GIS projects\geog485\Lesson4\Project 4 Parsing rhinoceros sightings\RhinoObservations.csv")
sr = arcpy.SpatialReference(4326)
exportPath = "W:/GIS projects/geog485/Lesson4/Project 4 Parsing rhinoceros sightings/"

csvReader = csv.reader(file, delimiter=",")
header = csvReader.next()

observerIndex = header.index("Observer")
latIndex = header.index("X")
longIndex = header.index("Y")
nameIndex = header.index("Rhino")
commentIndex = header.index("Comments")

rhino = {}

for row in csvReader:

	observer = row[observerIndex]
	lat = row[latIndex]
	long = row[longIndex]
	name = row[nameIndex]
	comment = row[commentIndex]
	coordinates = [lat, long]
	rhinoTracks(name, coordinates, rhino)

print 'rhino dictionary generated'
	
for item in rhino:
	exportTracks(item, rhino)

	
lastline = raw_input(">>>")