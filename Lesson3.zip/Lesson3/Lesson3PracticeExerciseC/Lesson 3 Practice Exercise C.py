import arcpy
arcpy.env.overwriteOutput = True

arcpy.env.workspace = r'W:\GIS projects\geog485\Lesson3\Lesson3PracticeExerciseC\Washington.gdb'

try:
	arcpy.MakeFeatureLayer_management('ParkAndRide', "ParkAndRide_lyr", 'Approx_Par'+'>500')
	print "ParkAndRide_lyr created"
	arcpy.CopyFeatures_management("ParkAndRide_lyr", "ParkAndRide_500")
	print "ParkAndRide_500 exported" 
	
except:
	arcpy.AddMessage(arcpy.GetMessages())
	
finally:
	arcpy.Delete_management("ParkAndRide_lyr")
	
	
lastline = raw_input(">>>")
