import arcpy
arcpy.env.overwriteOutput = True

arcpy.env.workspace = r"W:\GIS projects\geog485\Lesson3\Lesson3PracticeExerciseB\Washington.gdb"



try:
	with arcpy.da.SearchCursor(CityBoundaries, ["CI_FIPS", ]) as cursor:
		for row in cursor:
			queryString = '"' + cityIDStringField + '" = ' + "'" + cityIDString + "'"
			arcpy.MakeFeatureLayer_management(CityBoundaries, 'CurrentCityLayer', )




	# citiesTwoWithParkAndRide = 0
	with arcpy.da.SearchCursor(CityBoundariesfc, ["NAME", "HasTwoParkAndRides"]) as cursor:
		for row in cursor:
			print row[0], row[1]
			arcpy.MakeFeatureLayer_management(row, 'CitiesLayer')
			arcpy.SelectLayerByLocation_management('FacilitiesLayer', 'WITHIN', "CitiesLayer")
			print int(arcpy.GetCount_management('FacilitiesLayer')[0])  
			arcpy.Delete_management("CitiesLayer")
			# row[1] = "True"
			# cursor.updateRow(row)
			# citiesTwoWithParkAndRide +=1
			# print row[0] + " has been updated."

except:
	arcpy.AddMessage(arcpy.GetMessages())

finally: 
    arcpy.Delete_management("FacilitiesLayer")
    

# print str(citiesWithParkAndRide/count) + " % of cities that have a park and ride facility."

lastline = raw_input(">>>")