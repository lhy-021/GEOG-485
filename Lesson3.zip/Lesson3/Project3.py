import arcpy
points = r'W:\GIS projects\geog485\Lesson3\Project3Data\OSMpoints.shp'
countries = r'W:\GIS projects\geog485\Lesson3\Project3Data\CentralAmerica.shp'
amenities = ['school','hospital','place_of_worship']

try:
	currentCountry = 'El Salvador'
	countrySelectionClause = 'NAME' + '=' + "'" + currentCountry + "'"
	arcpy.MakeFeatureLayer_management(countries, "CurrentCountry_lyr", countrySelectionClause)
	print currentCountry + "_lyr created"

	for amenity in amenities:
		amenitySelectionClause = '"amenity" = ' + "'" + amenity + "'"
		arcpy.MakeFeatureLayer_management(points, "CurrentAmenity_lyr", amenitySelectionClause)
		print amenity + "_lyr created"
		arcpy.SelectLayerByLocation_management ("CurrentAmenity_lyr", "WITHIN", "CurrentCountry_lyr")
		print amenity + "_lyr selected"
		for row in arcpy.SearchCursor("CurrentAmenity_lyr"):
			print row.name
		arcpy.Delete_management("CurrentAmenity_lyr")
		print amenity + "_lyr deleted"
		print "Next amenity item"
		print "------------------------------------------------"

except:
	arcpy.AddMessage(arcpy.GetMessages())
	
finally:
	arcpy.Delete_management("CurrentCountry_lyr")
	print currentCountry + "_lyr deleted"
	
lastline = raw_input(">>>")