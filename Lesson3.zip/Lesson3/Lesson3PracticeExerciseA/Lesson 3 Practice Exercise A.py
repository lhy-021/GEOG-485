import arcpy
arcpy.env.overwriteOutput = True

arcpy.env.workspace = r"W:\GIS projects\geog485\Lesson3\Lesson3PracticeExerciseA\Washington.gdb"
cities = 'CityBoundaries'
facilities = 'ParkAndRide'
arcpy.MakeFeatureLayer_management(cities, "CitiesLayer")
arcpy.MakeFeatureLayer_management(facilities, "FacilitiesLayer")

try:
	result = arcpy.GetCount_management("CitiesLayer")
	count = int(result.getOutput(0))
	print "There is a toal of " + str(count) + " cities."

except:
	print "Can not count."

arcpy.SelectLayerByLocation_management("CitiesLayer","CONTAINS","FacilitiesLayer")

try:
	citiesWithParkAndRide=0
	with arcpy.da.UpdateCursor("CitiesLayer", ["NAME", "HasParkAndRide"]) as cursor:
		for row in cursor:
			row[1] = "True"
			cursor.updateRow(row)
			citiesWithParkAndRide +=1
			print row[0] + " has been updated."

except:
	arcpy.AddMessage(arcpy.GetMessages())

finally: 
    arcpy.Delete_management("FacilitiesLayer")
    arcpy.Delete_management("CitiesLayer")

print str(citiesWithParkAndRide/count) + " % of cities that have a park and ride facility."

lastline = raw_input(">>>")