import arcpy
arcpy.env.overwriteOutput = True

arcpy.env.workspace = r'W:\GIS projects\geog485\Lesson3\Lesson3PracticeExerciseD\Washington.gdb'
currentCity = 'Federal Way'

try:
	selectionQuery = 'NAME' + '=' + "'" + currentCity + "'"
	
	arcpy.MakeFeatureLayer_management('CityBoundaries', "CurrentCity_lyr", selectionQuery)
	print "CurrentCity_lyr created"
	
	arcpy.MakeFeatureLayer_management('ParkAndRide', "ParkAndRide_lyr")
	print "ParkAndRide_lyr created"
	
	arcpy.SelectLayerByLocation_management("ParkAndRide_lyr","WITHIN","CurrentCity_lyr")
	print "Features in ParkAndRide_lyr selected"
	
	arcpy.CopyFeatures_management("ParkAndRide_lyr", "ParkAndRide_in_" + currentCity)
	print "ParkAndRide_in_" + currentCity + " exported" 

	
except:
	arcpy.AddMessage(arcpy.GetMessages())
	
finally:
	arcpy.Delete_management("CurrentCity_lyr")
	arcpy.Delete_management("ParkAndRide_lyr")
	
	
lastline = raw_input(">>>")
