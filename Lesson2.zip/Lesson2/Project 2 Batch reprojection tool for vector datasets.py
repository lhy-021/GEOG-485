import arcpy
import os

arcpy.env.workspace = arcpy.GetParameterAsText(0)
target_feature_class = arcpy.GetParameterAsText(1)
out_coordinate_system = arcpy.Describe(target_feature_class).spatialReference
try:
    for input_feature in arcpy.ListFeatureClasses():
         if arcpy.Describe(input_feature).spatialReference.Name==out_coordinate_system.Name:
            print ('skipped this fc due to same coordinate system as the target fc: ' + input_feature)
         else:
            output_feature_class = os.path.splitext(input_feature)[0]+'_projected'
            arcpy.Project_management(input_feature, output_feature_class, out_coordinate_system)
            arcpy.AddMessage(arcpy.GetMessages()) 
except arcpy.ExecuteError:
    arcpy.AddMessage(arcpy.GetMessages()) 
