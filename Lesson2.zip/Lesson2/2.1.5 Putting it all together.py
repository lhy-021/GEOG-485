from random import *
spinAction = [-1, -2, -3, -4, 2, 2, 10]
turns = 0
balance = 10
while balance > 0:
	spinIndex = randint(0,6)
        if spinIndex == 6:
                balance = 10
                turns +=1
                print 'Result of the spin ' + str(spinAction[spinIndex])
                print 'The number of cherries on your tree after this turn ' + str(balance)
        else:     
                balance += spinAction[spinIndex]
                turns +=1
                print 'Result of the spin ' + str(spinAction[spinIndex])
                print 'The number of cherries on your tree after this turn ' + str(balance)
print turns
lastline = raw_input(">>>")
